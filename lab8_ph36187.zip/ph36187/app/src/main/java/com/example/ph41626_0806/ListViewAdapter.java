package com.example.ph41626_0806;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter {
    final Context context;
    final ArrayList<Teacher> lstTeacher;
    Button btn_add_dialog,cancel;
    public ListViewAdapter(Context context, ArrayList<Teacher> lstTeacher) {
        this.context = context;
        this.lstTeacher = lstTeacher;
    }

    @Override
    public int getCount() {
        return lstTeacher.size();
    }

    @Override
    public Object getItem(int position) {
        return lstTeacher.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    TextView ma_gv,name_gv;
    EditText txt_magv;
    EditText txt_tengv;
    TextView title;
    ImageButton edit,delete;
    Service service = new Service();
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = ((Activity) context).getLayoutInflater();
        convertView = layoutInflater.inflate(R.layout.item_gv,parent,false);

        ma_gv = convertView.findViewById(R.id.ma_gv);
        name_gv = convertView.findViewById(R.id.name_gv);
        edit = convertView.findViewById(R.id.btn_edit);
        delete = convertView.findViewById(R.id.btn_delete);

        ma_gv.setText("Mã GV: " + lstTeacher.get(position).getMagv());
        name_gv.setText("Tên GV: " + lstTeacher.get(position).getTengv());

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lstTeacher.remove(position);
                notifyDataSetChanged();
                Toast.makeText(context, "Đã xóa 1 giáo viên!", Toast.LENGTH_SHORT).show();
                service.writeFile(context,lstTeacher,"teacher.txt");
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.dialog_addgv);
                Window window = dialog.getWindow();
                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT);

                txt_magv = dialog.findViewById(R.id.txt_magv);
                txt_tengv = dialog.findViewById(R.id.txt_tengv);
                btn_add_dialog = dialog.findViewById(R.id.btn_add_dialog);
                cancel = dialog.findViewById(R.id.cancel);
                title = dialog.findViewById(R.id.title);

                txt_magv.setText(lstTeacher.get(position).getMagv());
                txt_tengv.setText(lstTeacher.get(position).getTengv());
                title.setText("Sửa thông tin.");

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                btn_add_dialog.setText("Sửa");
                btn_add_dialog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String magv = txt_magv.getText().toString().trim();
                        String tengv = txt_tengv.getText().toString().trim();
                        if(magv.isEmpty() || tengv.isEmpty()) {
                            Toast.makeText(context, "Không được để trống thông tin!", Toast.LENGTH_SHORT).show();
                        } else {
                            lstTeacher.get(position).setMagv(magv);
                            lstTeacher.get(position).setTengv(tengv);
                            notifyDataSetChanged();
                            Toast.makeText(context, "Sửa thành công!", Toast.LENGTH_SHORT).show();
                            service.writeFile(context,lstTeacher,"teacher.txt");
                            dialog.dismiss();
                        }
                    }
                });

                dialog.show();
            }
        });
        return convertView;

    }
}
