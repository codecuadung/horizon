package com.example.ph41626_0806;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    ListView listview_gv;
    Button add_gv;
    ListViewAdapter listViewAdapter;
    ArrayList<Teacher> lstTeacher = new ArrayList<>();
    EditText txt_magv;
    EditText txt_tengv;
    TextView title;
    Service service = new Service();
    Button btn_add_dialog,cancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        listview_gv = findViewById(R.id.listview_gv);
        add_gv = findViewById(R.id.add_gv);

//        fakeData();
        lstTeacher = service.readStaff(HomeActivity.this,"teacher.txt");
        listViewAdapter = new ListViewAdapter(HomeActivity.this,lstTeacher);
        listview_gv.setAdapter(listViewAdapter);
        add_gv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(HomeActivity.this);
                dialog.setContentView(R.layout.dialog_addgv);
                Window window = dialog.getWindow();
                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT);

                txt_magv = dialog.findViewById(R.id.txt_magv);
                txt_tengv = dialog.findViewById(R.id.txt_tengv);
                btn_add_dialog = dialog.findViewById(R.id.btn_add_dialog);
                cancel = dialog.findViewById(R.id.cancel);
                title = dialog.findViewById(R.id.title);

                title.setText("Thêm Giáo Viên");

                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                btn_add_dialog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String magv = txt_magv.getText().toString().trim();
                        String tengv = txt_tengv.getText().toString().trim();
                        if(magv.isEmpty() || tengv.isEmpty()) {
                            Toast.makeText(HomeActivity.this, "Không được để trống thông tin!", Toast.LENGTH_SHORT).show();
                        } else {
                            lstTeacher.add(new Teacher(magv,tengv));
                            Toast.makeText(HomeActivity.this, "Thêm thành công!", Toast.LENGTH_SHORT).show();
                            service.writeFile(HomeActivity.this,lstTeacher,"teacher.txt");
                            dialog.dismiss();
                            listViewAdapter = new ListViewAdapter(HomeActivity.this,lstTeacher);
                            listview_gv.setAdapter(listViewAdapter);
                        }
                    }
                });
                dialog.show();
            }
        });
    }
    private void fakeData() {
        lstTeacher.add(new Teacher("GV11111","Nguyễn Văn A"));
        lstTeacher.add(new Teacher("GV22222","Nguyễn Văn B"));
        lstTeacher.add(new Teacher("GV33333","Nguyễn Văn C"));
        lstTeacher.add(new Teacher("GV44444","Nguyễn Văn D"));
        lstTeacher.add(new Teacher("GV55555","Nguyễn Văn E"));

    }
}