package com.example.ph41626_0806;

import java.io.Serializable;

public class Teacher implements Serializable {
    private String magv;
    private String tengv;

    public Teacher(String magv, String tengv) {
        this.magv = magv;
        this.tengv = tengv;
    }

    public String getMagv() {
        return magv;
    }

    public void setMagv(String magv) {
        this.magv = magv;
    }

    public String getTengv() {
        return tengv;
    }

    public void setTengv(String tengv) {
        this.tengv = tengv;
    }
}
