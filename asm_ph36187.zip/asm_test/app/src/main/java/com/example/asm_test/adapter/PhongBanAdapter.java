package com.example.asm_test.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.asm_test.Model.PhongBan;
import com.example.asm_test.Model.nhanvien;
import com.example.asm_test.R;

import java.util.ArrayList;

public class PhongBanAdapter extends BaseAdapter
implements Filterable {

    //xử lý dữ liệu
    private Context context;
    private ArrayList<PhongBan> listPB,listOld;

    public PhongBanAdapter(Context context, ArrayList<PhongBan> listPB) {
        this.context = context;
        this.listOld = listPB;
        this.listPB = listPB;
    }

    @Override
    public int getCount() {
        return listPB.size();
    }

    @Override
    public Object getItem(int position) {
        return listPB.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = ((Activity)context).getLayoutInflater();
        View view = inflater.inflate(R.layout.item_phongban,parent,false);

        TextView txtTenPB = view.findViewById(R.id.txtTenPB);
        String data = listPB.get(position).getMapb()+ " - " +listPB.get(position).getTenpb();
        txtTenPB.setText(data);
        return view;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String s = constraint.toString();
                if(s.isEmpty()){
                    listPB = listOld;
                }else {
                    ArrayList<PhongBan>listS = new ArrayList<>();
                    for (PhongBan st: listOld
                    ) {
                        if(st.getTenpb().toLowerCase().contains(s.toLowerCase())){
                            listS.add(st);
                        }
                    }
                    listPB = listS;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = listPB;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                listPB = (ArrayList<PhongBan>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}
