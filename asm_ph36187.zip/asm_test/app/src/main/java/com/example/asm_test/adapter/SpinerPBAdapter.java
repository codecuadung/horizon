package com.example.asm_test.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.asm_test.Model.PhongBan;
import com.example.asm_test.R;

import java.util.ArrayList;

public class SpinerPBAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<PhongBan> listPB;

    public SpinerPBAdapter(Context context, ArrayList<PhongBan> listPB) {
        this.context = context;
        this.listPB = listPB;
    }

    @Override
    public int getCount() {
        return listPB.size();
    }

    @Override
    public Object getItem(int position) {
        return listPB.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = ((Activity)context).getLayoutInflater();
        View view = inflater.inflate(R.layout.item_phongban,parent,false);
        TextView txtTenPB = view.findViewById(R.id.txtTenPB);
        txtTenPB.setText(listPB.get(position).getTenpb());
        return view;
    }
}
