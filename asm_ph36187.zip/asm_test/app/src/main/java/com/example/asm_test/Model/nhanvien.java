package com.example.asm_test.Model;


import java.io.Serializable;

public class nhanvien implements Serializable {
    private String tencs;
    private String hoten;
    private String diachi;

    public nhanvien() {
    }

    public nhanvien(String tencs, String hoten, String diachi) {
        this.tencs = tencs;
        this.hoten = hoten;
        this.diachi = diachi;
    }

    public String getTencs() {
        return tencs;
    }

    public void setTencs(String tencs) {
        this.tencs = tencs;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }
}

