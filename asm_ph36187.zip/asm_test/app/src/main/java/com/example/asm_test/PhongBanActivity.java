package com.example.asm_test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.asm_test.Model.PhongBan;
import com.example.asm_test.adapter.PhongBanAdapter;

import java.util.ArrayList;

public class PhongBanActivity extends AppCompatActivity {
    ListView lvPhongBan;
    private  ArrayList<PhongBan> listPB;
    SearchView svPhongBan;
    Toolbar toolbar;
    PhongBanAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phong_ban);
        toolbar = findViewById(R.id.demo61Toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Phòng ban");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

         lvPhongBan = findViewById(R.id.lvPhongban);
        loadData(getDSPB());

        //xử lý searchview
        //lắng nghe sk nhập keyword lên searchview

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.demo61_menu,menu);
        MenuItem myActionMenuItem = menu.findItem(R.id.action_search);
        svPhongBan = (SearchView) myActionMenuItem.getActionView();
        svPhongBan.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return true;
    }

    private void loadData(ArrayList<PhongBan>list){
        adapter = new PhongBanAdapter(PhongBanActivity.this,list);
        lvPhongBan.setAdapter(adapter);
    }
    public ArrayList<PhongBan>getDSPB(){
        listPB = new ArrayList<>();
        listPB.add(new PhongBan("PB01", "Nhân sự"));
        listPB.add(new PhongBan("PB02", "Hành chính"));
        listPB.add(new PhongBan("PB03", "Đào tạo"));
        return listPB;

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}