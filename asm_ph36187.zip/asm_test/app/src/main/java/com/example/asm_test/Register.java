package com.example.asm_test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        TextInputEditText edtUser = findViewById(R.id.edtUser);
        TextInputLayout txtUser =findViewById(R.id.txtUser);
        TextInputEditText edtPass = findViewById(R.id.edtPass);
        TextInputLayout txtPass = findViewById(R.id.txtPass);
        TextInputEditText edtRePass = findViewById(R.id.edtRePass);
        TextInputLayout txtRePass =findViewById(R.id.txtRePass);
        Button btnRegister = findViewById(R.id.btnRegister);
        Button btnBack = findViewById(R.id.btnBack);

        edtUser.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() == 0){
                    txtUser.setError("Vui lòng nhập username");
                }else{
                    txtUser.setError(null);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        edtPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() == 0){
                    txtPass.setError("Vui lòng nhập password");
                }else{
                    txtPass.setError(null);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        edtRePass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() == 0){
                    txtRePass.setError("Vui lòng nhập lại password");
                }else{
                    txtRePass.setError(null);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = edtUser.getText().toString();
                String pass = edtPass.getText().toString();
                String repass = edtRePass.getText().toString();

                if(user.isEmpty()||pass.isEmpty()||repass.isEmpty()){
                    if(user.isEmpty()){
                        txtUser.setError("Vui lòng nhập username");
                    }else {
                        txtUser.setError(null);
                    }
                    if(pass.isEmpty()){
                        txtPass.setError("Vui lòng nhập password");
                    }else {
                        txtPass.setError(null);
                    }
                    if(repass.isEmpty()){
                        txtRePass.setError("Vui lòng nhập lại password");
                    }else {
                        txtRePass.setError(null);
                    }
                }else if(!pass.equals(repass)){
                    edtPass.setText("");
                    edtRePass.setText("");
                    Toast.makeText(Register.this,"Mật khẩu không trùng khớp",Toast.LENGTH_SHORT).show();
                }else{

                    Toast.makeText(Register.this,"Đăng ký thành công",Toast.LENGTH_SHORT).show();

                }
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = edtUser.getText().toString();
                String pass = edtPass.getText().toString();
                String repass = edtRePass.getText().toString();
                Intent intent = new Intent();
                intent.putExtra("user",user);
                intent.putExtra("pass",pass);
                setResult(1,intent);
                finish();
            }
        });
    }
}