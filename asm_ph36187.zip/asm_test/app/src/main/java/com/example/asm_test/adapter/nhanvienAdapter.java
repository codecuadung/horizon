package com.example.asm_test.adapter;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;


import com.example.asm_test.Model.nhanvien;
import com.example.asm_test.R;

import java.util.ArrayList;

public class nhanvienAdapter extends BaseAdapter
implements Filterable {
    private Context context;
    private  ArrayList<nhanvien> list, listOld;

    public nhanvienAdapter(Context context, ArrayList<nhanvien> list) {
        this.context = context;
        this.listOld = list;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = ((Activity)context).getLayoutInflater();
        convertView = inflater.inflate(R.layout.item_listnv,parent,false);
        //ánh xạ
        TextView txttencs = convertView.findViewById(R.id.txttencs);
        TextView txtht = convertView.findViewById(R.id.txtht);
        TextView txtdc = convertView.findViewById(R.id.txtdc);
        Button btnupdate = convertView.findViewById(R.id.btnupdate);
        Button btnxoa = convertView.findViewById(R.id.btnxoa);

        //cập nhật dữ liệu (gán dữ liệu)
        txttencs.setText(list.get(position).getTencs());
        txtdc.setText(list.get(position).getDiachi());
        txtht.setText(list.get(position).getHoten());
        //
        btnxoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list.remove(position);
                notifyDataSetChanged();
            }
        });
        nhanvien nv = list.get(position);
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendialog(nv);
            }
        });
        return convertView;
    }
    public void opendialog(nhanvien sv){
        AlertDialog.Builder builder=new AlertDialog.Builder(context);
        LayoutInflater inflater=((Activity)context).getLayoutInflater();
        View view=inflater.inflate(R.layout.item_update,null);
        builder.setView(view);
        Dialog dialog=builder.create();
        dialog.show();
        //anh xa
        EditText txtcs = view.findViewById(R.id.txtcs_ud);
        EditText txtten = view.findViewById(R.id.txtten_up);
        EditText txtdiachi = view.findViewById(R.id.txtdiachi_up);
        Button btnupdate=view.findViewById(R.id.btnud);
        //gán du lieu lên các textview
        txtcs.setText(sv.getTencs());
        txtten.setText(sv.getHoten());
        txtdiachi.setText(sv.getDiachi());
        //click update
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sv.setTencs("Mã nhân viên: "+txtcs.getText().toString());
                sv.setHoten("Họ tên: "+txtten.getText().toString());
                sv.setDiachi("Phòng ban: " +txtdiachi.getText().toString());
                dialog.dismiss();
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String s = constraint.toString();
                if(s.isEmpty()){
                    list = listOld;
                }else {
                    ArrayList<nhanvien>listS = new ArrayList<>();
                    for (nhanvien st: listOld
                         ) {
                        if(st.getHoten().toLowerCase().contains(s.toLowerCase())){
                            listS.add(st);
                        }
                    }
                    list = listS;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = list;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                list = (ArrayList<nhanvien>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}
