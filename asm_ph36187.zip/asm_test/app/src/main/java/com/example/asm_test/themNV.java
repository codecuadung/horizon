package com.example.asm_test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.example.asm_test.Model.PhongBan;
import com.example.asm_test.Model.nhanvien;
import com.example.asm_test.adapter.SpinerPBAdapter;

import java.util.ArrayList;

public class themNV extends AppCompatActivity {
    private String tenpb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_them_nv);
        EditText edtMaNV = findViewById(R.id.edtMaNV);
        EditText edtTenNV = findViewById(R.id.edtTenNV);
        Spinner spnTenPB = findViewById(R.id.spnTenPB);
        Button btnThemNV = findViewById(R.id.btnThemNV);
        Button btnTroVe = findViewById(R.id.btnTroVe);
        //set adapter
        ArrayList<PhongBan> listPB = new PhongBanActivity().getDSPB();
        SpinnerAdapter adapter = new SpinerPBAdapter(themNV.this,listPB);
        spnTenPB.setAdapter(adapter);

        spnTenPB.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            //chạy khi được chọn
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                tenpb = listPB.get(position).getTenpb();
            }

            @Override
            //chạy khi không chọn
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btnThemNV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String manv = edtMaNV.getText().toString();
                String tennv = edtTenNV.getText().toString();
                if(manv.isEmpty()){
                    edtMaNV.setError("Vui lòng nhập mã nhân viên");
                }
                if(tennv.isEmpty()){
                    edtTenNV.setError("Vui lòng nhập tên nhân viên");
                }
                if(manv.length()>0&&tennv.length()>0){
                    nhanvien nhanvienmoi = new nhanvien(manv,tennv,tenpb);
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("nhanvienmoi",nhanvienmoi);
                    intent.putExtras(bundle);
                    setResult(1,intent);
                    finish();
                }
            }
        });
        btnTroVe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}