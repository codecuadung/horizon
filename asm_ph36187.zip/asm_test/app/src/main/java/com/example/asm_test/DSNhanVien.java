package com.example.asm_test;


import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;


import com.example.asm_test.Model.nhanvien;
import com.example.asm_test.adapter.nhanvienAdapter;

import java.util.ArrayList;

public class DSNhanVien extends AppCompatActivity {

    ListView listhome;
    Toolbar toolbar;
    nhanvienAdapter adapter;
    SearchView searchView;
    private ArrayList<nhanvien>list = new ArrayList<nhanvien>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dsnhan_vien);

        //ánh xạ

        Button btnadd  = findViewById(R.id.btnadd);
        toolbar = findViewById(R.id.demo61Toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Nhân viên");

        listhome = findViewById(R.id.lsthome);
        //thêm đối tượng vào list
        list.add(new nhanvien("Mã nhân viên: "+"NV001","Họ tên: "+"Nguyễn Văn B","Phòng ban: "+"Hành chính"));
        list.add(new nhanvien("Mã nhân viên: "+"NV002","Họ tên: "+"Nguyễn Văn C","Phòng ban: "+"Nhân sự"));
        list.add(new nhanvien("Mã nhân viên: "+"NV003","Họ tên: "+"Nguyễn Văn D","Phòng ban: "+"Nhân sự"));
        list.add(new nhanvien("Mã nhân viên: "+"NV004","Họ tên: "+"Nguyễn Văn E","Phòng ban: "+"Đào tạo"));
        //đổ dữ liệu lên list view
       loadData();

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DSNhanVien.this, themNV.class);
                myLauncher.launch(intent);
            }
        });


    }
    private void loadData(){
        adapter = new nhanvienAdapter(this,list);
        listhome.setAdapter(adapter);
    }
    private ActivityResultLauncher<Intent> myLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            //xử lý dữ liệu trả về
                            //thêm trả về
                            if(result.getResultCode()==1){
                                Intent intent = result.getData();
                                Bundle bundle = intent.getExtras();
                                nhanvien nhanvienmoi = (nhanvien) bundle.getSerializable("nhanvienmoi");
                                list.add(nhanvienmoi);
                                loadData();
                            }
                        }
                    });

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.demo61_menu,menu);
        MenuItem myActionMenuItem = menu.findItem(R.id.action_search);
        searchView = (SearchView) myActionMenuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });

        return true;
    }

    @Override

    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}