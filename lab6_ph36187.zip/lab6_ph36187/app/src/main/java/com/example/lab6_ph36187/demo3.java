package com.example.lab6_ph36187;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class demo3 extends AppCompatActivity {

    String [] ten = new String[]{"Tom","jerry","Hoa","Hồng","Dũng","Dương"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo3);
        Toolbar toolbar = findViewById(R.id.demo61Toolbar1);
        setSupportActionBar(toolbar);

        ListView lstcontext = findViewById(R.id.lstcontext);
        //đổ dữ liệu
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,ten);
        lstcontext.setAdapter(adapter);
        registerForContextMenu(lstcontext);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.demo61,menu);
        return true;
    }
}