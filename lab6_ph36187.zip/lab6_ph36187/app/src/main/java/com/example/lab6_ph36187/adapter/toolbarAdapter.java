package com.example.lab6_ph36187.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;

public class toolbarAdapter implements Filterable{

   
    @Override
    public Filter getFilter() {
        return null;
    }
}
