package com.example.dungptph36187_duanmau.DAO;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.dungptph36187_duanmau.database.DbHelper;
import com.example.dungptph36187_duanmau.model.ThanhVienmodel;

import java.util.ArrayList;
import java.util.List;

public class ThanhvienDAO {
    private SQLiteDatabase db;
    public ThanhvienDAO(Context context){
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
    }
    public long insert(ThanhVienmodel obj){
        ContentValues values = new ContentValues();
        values.put("hoTen",obj.getHoTen());
        values.put("namSinh",obj.getNamSinh());
        return db.insert("ThanhVien",null,values);
    }
    public int update(ThanhVienmodel obj){
        ContentValues values = new ContentValues();
        values.put("hoTen",obj.getHoTen());
        values.put("namSinh",obj.getNamSinh());
        return db.update("ThanhVien",values,"maTV=?",new String[]{String.valueOf(obj.getMaTV())});
    }
    public int delete(String id){
        return db.delete("ThanhVien","maTV=?",new String[]{id});
    }
    @SuppressLint("Range")
    public List<ThanhVienmodel>getData(String sql, String...selectionArgs){
        List<ThanhVienmodel>list = new ArrayList<>();
        Cursor c = db.rawQuery(sql,selectionArgs);
        while (c.moveToNext()){
            ThanhVienmodel obj = new ThanhVienmodel();
            obj.setMaTV(Integer.parseInt(c.getString(c.getColumnIndex("maTV"))));
            obj.setHoTen(c.getString(c.getColumnIndex("hoTen")));
            obj.setNamSinh(c.getString(c.getColumnIndex("namSinh")));
            list.add(obj);
            Log.i("//========",obj.toString());
        }
        return list;
    }
    public List<ThanhVienmodel>getAll(){
        String sql = "SELECT * FROM ThanhVien";
        return getData(sql);
    }
    public ThanhVienmodel getid(String id){
        String sql = "SELECT * FROM Thanhvien WHERE maTV=?";
        List<ThanhVienmodel>list = getData(sql,id);
        return list.get(0);
    }
}
