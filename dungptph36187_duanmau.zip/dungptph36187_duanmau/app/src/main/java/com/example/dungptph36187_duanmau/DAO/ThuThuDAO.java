package com.example.dungptph36187_duanmau.DAO;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.dungptph36187_duanmau.database.DbHelper;
import com.example.dungptph36187_duanmau.model.ThanhVienmodel;
import com.example.dungptph36187_duanmau.model.ThuThumodel;

import java.util.ArrayList;
import java.util.List;

public class ThuThuDAO {
    private SQLiteDatabase db;
    public ThuThuDAO(Context context){
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
    }
    public long insert(ThuThumodel obj){
        ContentValues values = new ContentValues();
        values.put("maTT",obj.getMaTT());
        values.put("hoTen",obj.getHoTen());
        values.put("matKhau",obj.getMatKhau());
        return db.insert("ThuThu",null,values);
    }
    public int updatePass(ThuThumodel obj){
        ContentValues values = new ContentValues();
        values.put("hoTen",obj.getHoTen());
        values.put("matKhau",obj.getMatKhau());
        return db.update("ThuThu",values,"maTT=?",new String[]{String.valueOf(obj.getMaTT())});
    }
    public int delete(String id){
        return db.delete("ThuThu","maTT=?",new String[]{id});
    }
    @SuppressLint("Range")
    public List<ThuThumodel> getData(String sql, String...selectionArgs){
        List<ThuThumodel>list = new ArrayList<ThuThumodel>();
        Cursor c = db.rawQuery(sql,selectionArgs);
        while (c.moveToNext()){
            ThuThumodel obj = new ThuThumodel();
            obj.setMaTT((c.getString(c.getColumnIndex("maTT"))));
            obj.setHoTen(c.getString(c.getColumnIndex("hoTen")));
            obj.setMatKhau(c.getString(c.getColumnIndex("matKhau")));
            Log.i("//========",obj.toString());
            list.add(obj);
        }
        return list;
    }
    public List<ThuThumodel>getAll(){
        String sql = "SELECT * FROM ThuThu";
        return getData(sql);
    }
    public ThuThumodel getid(String id){
        String sql = "SELECT * FROM ThuThu WHERE maTT?";
        List<ThuThumodel>list = getData(sql,id);
        return list.get(0);
    }
    public int checkLogin(String id,String password){
        String sql = "SELECT * FROM ThuThu WHERE maTT=? AND matKhau=?";
        List<ThuThumodel>list = getData(sql,id,password);
        if(list.size()==0)
            return -1;
        return 1;

    }
}
