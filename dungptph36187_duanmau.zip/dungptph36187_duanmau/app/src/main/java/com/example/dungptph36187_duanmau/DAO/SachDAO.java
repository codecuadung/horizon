package com.example.dungptph36187_duanmau.DAO;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.dungptph36187_duanmau.database.DbHelper;
import com.example.dungptph36187_duanmau.model.LoaiSachmodel;
import com.example.dungptph36187_duanmau.model.Sachmodel;

import java.util.ArrayList;
import java.util.List;

public class SachDAO {
    private SQLiteDatabase db;
    public SachDAO(Context context){
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
    }
    public long insert(Sachmodel obj){
        ContentValues values = new ContentValues();
        values.put("maLoai",obj.getMaLoai());
        values.put("tenSach",obj.getTenSach());
        values.put("giaThue",obj.getGiaThue());
        return db.insert("Sach",null,values);
    }
    public int update(Sachmodel obj){
        ContentValues values = new ContentValues();
        values.put("maLoai",obj.getMaLoai());
        values.put("tenSach",obj.getTenSach());
        values.put("giaThue",obj.getGiaThue());
        return db.update("Sach",values,"maSach=?",new String[]{String.valueOf(obj.getMaSach())});
    }
    public int delete(String id){
        return db.delete("Sach","maSach=?",new String[]{id});
    }
    @SuppressLint("Range")
    public List<Sachmodel> getData(String sql, String...selectionArgs){
        List<Sachmodel>list = new ArrayList<>();
        Cursor c = db.rawQuery(sql,selectionArgs);
        while (c.moveToNext()){
            Sachmodel obj = new Sachmodel();
            obj.setMaLoai(Integer.parseInt(c.getString(c.getColumnIndex("maLoai"))));
            obj.setMaSach(Integer.parseInt(c.getString(c.getColumnIndex("maSach"))));
            obj.setGiaThue(Integer.parseInt(c.getString(c.getColumnIndex("giaThue"))));
            obj.setTenSach(c.getString(c.getColumnIndex("tenSach")));
            list.add(obj);
        }
        return list;
    }
    public List<Sachmodel>getAll(){
        String sql = "SELECT * FROM Sach";
        return getData(sql);
    }
    public Sachmodel getid(String id){
        String sql = "SELECT * FROM Sach WHERE maSach=?";
        List<Sachmodel>list = getData(sql,id);
        return list.get(0);
    }
}
