package com.example.ktlab7_ph36187;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class Viewpageadapter extends FragmentStateAdapter {
    public Viewpageadapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0:return new frmdanhsachkh();
            case 1:return new frmthongtin();
        }
        return null;
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}

