package com.example.ktlab7_ph36187;

import android.app.Dialog;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.example.ktlab7_ph36187.Adapter.khachhangadapter;
import com.example.ktlab7_ph36187.DAO.khachhangDAO;
import com.example.ktlab7_ph36187.Model.khachhangmodel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class frmdanhsachkh extends Fragment {
    private RecyclerView rcvsanpham;
    private FloatingActionButton floadadd;
    private khachhangDAO dao;
    khachhangadapter adapter;
    private ArrayList<khachhangmodel> list = new ArrayList<>();

    public frmdanhsachkh() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_frmdanhsachkh, container, false);
        // Inflate the layout for this fragment
        rcvsanpham = view.findViewById(R.id.recyclerproduct);
        floadadd = view.findViewById(R.id.floadadd);
        dao = new khachhangDAO(getContext());
        list = dao.getds();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        rcvsanpham.setLayoutManager(linearLayoutManager);
        adapter = new khachhangadapter(getContext(),list);
        rcvsanpham.setAdapter(adapter);
        floadadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        return view;
    }
}