package com.example.ktlab7_ph36187.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.ktlab7_ph36187.Database.DbHelper;
import com.example.ktlab7_ph36187.Model.khachhangmodel;

import java.util.ArrayList;

public class khachhangDAO {
    private DbHelper dbHelper;

    public khachhangDAO(Context context) {
        dbHelper = new DbHelper(context);
    }
    public ArrayList<khachhangmodel> getds() {
        ArrayList<khachhangmodel> list = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = dbHelper.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM KHACHHANG", null);

        if (cursor.moveToFirst()) {
            do {
                int makh = cursor.getInt(0);
                String tenkh = cursor.getString(1);
                String quequan = cursor.getString(2);
                String gioitinh = cursor.getString(3);
                String ngaysinh = cursor.getString(4);

                list.add(new khachhangmodel(makh, tenkh, quequan, gioitinh,ngaysinh));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }
    public boolean insert(khachhangmodel kh) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();//ghi dl vào db
        ContentValues values = new ContentValues();//đưa dl vào database
        values.put("tenkh",kh.getTenkh());
        values.put("quequan",kh.getQuequan());
        values.put("gioitinh",kh.getGioitinh());
        values.put("ngaysinh",kh.getNgaysinh());
        //nếu add dl thành công thì trả về giá trị tương ứng với số dòng được chèn vào
        long row = db.insert("khachhang",null,values);
        return (row>0);

    }
    //update dl
    public boolean update(khachhangmodel kh){
        SQLiteDatabase db = dbHelper.getWritableDatabase();//ghi dl vào db
        ContentValues values = new ContentValues();//đưa dl vào database
        values.put("tenkh",kh.getTenkh());
        values.put("quequan",kh.getQuequan());
        values.put("gioitinh",kh.getGioitinh());
        values.put("ngaysinh",kh.getNgaysinh());
        //nếu add dl thành công thì trả về giá trị tương ứng với số dòng được chèn vào
        long row = db.update("sanpham",values,"makh = ?",new String[]{String.valueOf(kh.getMakh())});
        //điều kiện update nằm ở cột id
        return (row>0);
    }
    //xóa dl
    //tham số truyền vào là congviec hoặc giá trị cột
    public boolean delete(String tenkh) {
        SQLiteDatabase sqLiteDatabase = dbHelper.getWritableDatabase();
        int result = sqLiteDatabase.delete("KHACHHANG", "makh=?", new String[]{tenkh});
        return result > 0;
    }

}
