package com.example.ktlab7_ph36187.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    public DbHelper(Context context) {
        super(context, "AND102", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String qkhachhang = "CREATE TABLE KHACHHANG(makh INTEGER PRIMARY KEY AUTOINCREMENT,tenkh TEXT, quequan TEXT,gioitinh TEXT,ngaysinh TEXT)";
        db.execSQL(qkhachhang);

        String dkhachhang = "INSERT INTO KHACHHANG VALUES('1','Phùng Tiến Dũng','Hà Nội','Nam','21/11/2004'),('2','Nguyễn Tiến Đạt','Hà Nội','Nam','25/01/2004')";
        db.execSQL(dkhachhang);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion!= newVersion){
            db.execSQL("DROP TABLE IF EXISTS KHACHHANG");
            onCreate(db);
        }
    }
}
