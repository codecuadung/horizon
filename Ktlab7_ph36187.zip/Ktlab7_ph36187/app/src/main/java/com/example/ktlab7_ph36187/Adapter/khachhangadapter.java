package com.example.ktlab7_ph36187.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ktlab7_ph36187.DAO.khachhangDAO;
import com.example.ktlab7_ph36187.Model.khachhangmodel;
import com.example.ktlab7_ph36187.R;

import java.util.ArrayList;

public class khachhangadapter extends RecyclerView.Adapter<khachhangadapter.ViewHolder>{
    private final Context context;
    private final ArrayList<khachhangmodel>list;
    khachhangDAO dao;

    public khachhangadapter(Context context, ArrayList<khachhangmodel> list) {
        this.context = context;
        this.list = list;
        dao = new khachhangDAO(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = ((Activity)context).getLayoutInflater();
        View view = inflater.inflate(R.layout.item_khachhang,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txtTenkh.setText(list.get(position).getTenkh());
        holder.txtquequan.setText((list.get(position).getQuequan()));
        holder.txtgioitinh.setText((list.get(position).getGioitinh()));
        holder.txtngaysinh.setText((list.get(position).getNgaysinh()));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtTenkh,txtquequan,txtgioitinh,txtngaysinh,txtedit,txtdelete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtdelete = itemView.findViewById(R.id.txtDelete);
            txtedit = itemView.findViewById(R.id.txtEdit);
            txtTenkh = itemView.findViewById(R.id.txtTenkh);
            txtquequan = itemView.findViewById(R.id.txtquequan);
            txtgioitinh = itemView.findViewById(R.id.txtgioitinh);
            txtngaysinh = itemView.findViewById(R.id.txtngaysinh);
        }
    }
}
