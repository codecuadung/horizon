package com.example.ktlab7_ph36187.Model;

public class khachhangmodel {
    int makh;
    String tenkh,quequan,gioitinh,ngaysinh;

    public int getMakh() {
        return makh;
    }

    public void setMakh(int makh) {
        this.makh = makh;
    }

    public String getTenkh() {
        return tenkh;
    }

    public void setTenkh(String tenkh) {
        this.tenkh = tenkh;
    }

    public String getQuequan() {
        return quequan;
    }

    public void setQuequan(String quequan) {
        this.quequan = quequan;
    }

    public String getGioitinh() {
        return gioitinh;
    }

    public void setGioitinh(String gioitinh) {
        this.gioitinh = gioitinh;
    }

    public String getNgaysinh() {
        return ngaysinh;
    }

    public void setNgaysinh(String ngaysinh) {
        this.ngaysinh = ngaysinh;
    }

    public khachhangmodel(int makh, String tenkh, String quequan, String gioitinh, String ngaysinh) {
        this.makh = makh;
        this.tenkh = tenkh;
        this.quequan = quequan;
        this.gioitinh = gioitinh;
        this.ngaysinh = ngaysinh;
    }

    public khachhangmodel(String tenkh, String quequan, String gioitinh, String ngaysinh) {
        this.tenkh = tenkh;
        this.quequan = quequan;
        this.gioitinh = gioitinh;
        this.ngaysinh = ngaysinh;
    }

    public khachhangmodel() {
    }
}
