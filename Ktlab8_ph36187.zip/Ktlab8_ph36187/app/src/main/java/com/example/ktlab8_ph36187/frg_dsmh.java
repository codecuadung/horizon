package com.example.ktlab8_ph36187;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class frg_dsmh extends Fragment {
    DAO dao;
    RecyclerView rcvmh;
    monhocadapter adapter;
    FloatingActionButton fltadd;
    monhocmodel mh;
    private ArrayList<monhocmodel>list = new ArrayList<>();


    public frg_dsmh() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_frg_dsmh, container, false);
        rcvmh = view.findViewById(R.id.rcvmh);
        fltadd = view.findViewById(R.id.fltadd);
        dao = new DAO(getActivity());
        list = dao.selectAll();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        rcvmh.setLayoutManager(linearLayoutManager);
        adapter = new monhocadapter(getActivity(),list);
        rcvmh.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        fltadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add();
            }
        });

        // Inflate the layout for this fragment
        return view;
    }
    public void add(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = getLayoutInflater().inflate(R.layout.add,null);
        builder.setView(view);
        Dialog dialog = builder.create();
        dialog.show();

        EditText edtmadv = view.findViewById(R.id.edtma);
        EditText edtnd = view.findViewById(R.id.edtnd);
        EditText edtngay = view.findViewById(R.id.edngay);

        Button btnadd = view.findViewById(R.id.btnsm);

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(edtmadv.getText().toString())||TextUtils.isEmpty(edtnd.getText().toString())||TextUtils.isEmpty(edtngay.getText().toString())){
                    Toast.makeText(getActivity(), "Vui lòng không bỏ trống", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(realnumber(edtngay.getText().toString())==false){
                    Toast.makeText(getActivity(), "Số tiết phải là số", Toast.LENGTH_SHORT).show();
                    return;


                }
                if(Integer.parseInt(edtngay.getText().toString())<=15){
                    Toast.makeText(getActivity(), "Số tiết >15", Toast.LENGTH_SHORT).show();
                    return;

                }
                String ma = edtmadv.getText().toString();
                String ten = edtnd.getText().toString();
                int sotiet = Integer.parseInt(edtngay.getText().toString());

                mh = new monhocmodel(ma,ten,sotiet);
                if (dao.insert(mh)){
                    list.clear();
                    list.addAll(dao.selectAll());
                    adapter.notifyDataSetChanged();
                    dialog.dismiss();
                    Toast.makeText(getActivity(), "Thêm thành công", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(getActivity(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                }

            }
        });





    }
    public boolean realnumber(String vr){

        try {
            // Chuyển đổi chuỗi thành số thực
            Double.parseDouble (vr);
            // Nếu không có ngoại lệ, trả về true
            return true;
        } catch (NumberFormatException e) {

//            if (Double.parseDouble (vr)>0){
//                Toast.makeText(getActivity(), "giá phải > 0", Toast.LENGTH_SHORT).show();
//            }
            // Nếu có ngoại lệ, trả về false
            return false;
        }
    }
}