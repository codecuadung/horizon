package com.example.ktlab8_ph36187;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class monhocadapter extends RecyclerView.Adapter<monhocadapter.viewholder>{
    private final Context context;
    private final ArrayList<monhocmodel>list;
    DAO dao;

    public monhocadapter(Context context, ArrayList<monhocmodel> list) {
        this.context = context;
        this.list = list;
        dao = new DAO(context);
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = ((Activity)context).getLayoutInflater();
        View view = inflater.inflate(R.layout.item_ds,parent,false);

        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
        holder.txtma.setText(list.get(position).getMamh());
        holder.txtten.setText(list.get(position).getTenmh());
        holder.txtsotiet.setText(String.valueOf(list.get(position).getSotiet()));
        monhocmodel mh = list.get(position);
        holder.txtxoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Cảnh báo");
                builder.setMessage("Bạn có muốn xóa ?");
                builder.setPositiveButton("có", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if(dao.delete(mh.getMamh())){

                            list.clear();
                            list.addAll(dao.selectAll());
                            notifyDataSetChanged();
                            Toast.makeText(context, "Đã xóa", Toast.LENGTH_SHORT).show();

                        }
                    }
                });

                builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(context, "Không xóa", Toast.LENGTH_SHORT).show();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        holder.txtupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update(mh);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class viewholder extends RecyclerView.ViewHolder {
        TextView txtma,txtten,txtsotiet,txtxoa,txtupdate;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            txtma = itemView.findViewById(R.id.txtma);
            txtten = itemView.findViewById(R.id.txtnd);
            txtsotiet = itemView.findViewById(R.id.txtngay);
            txtxoa=itemView.findViewById(R.id.txtxoa);
            txtupdate = itemView.findViewById(R.id.txtupdate);
        }

        }
    public void update(monhocmodel mh) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
        View view = inflater.inflate(R.layout.upadate, null);
        builder.setView(view);
        Dialog dialog = builder.create();
        dialog.show();
        EditText edtma = view.findViewById(R.id.edtmau);
        EditText edtten = view.findViewById(R.id.edtndu);

        EditText edtsotiet = view.findViewById(R.id.edngayu);
        Button btnsm = view.findViewById(R.id.btnsmu);


        edtma.setText(mh.getMamh());
        edtten.setText(mh.getTenmh());
        edtsotiet.setText(String.valueOf(mh.getSotiet()));
        btnsm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(edtma.getText().toString()) || TextUtils.isEmpty(edtten.getText().toString()) || TextUtils.isEmpty(edtsotiet.getText().toString())) {
                    Toast.makeText(context, "Vui lòng không bỏ trống", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (realnumber(edtsotiet.getText().toString()) == false) {
                    Toast.makeText(context, "Số tiết phải là số", Toast.LENGTH_SHORT).show();
                    return;


                }
                if (Integer.parseInt(edtsotiet.getText().toString()) <= 15) {
                    Toast.makeText(context, "Số tiết phải >15", Toast.LENGTH_SHORT).show();
                    return;

                }


                mh.setMamh(edtma.getText().toString());
                mh.setTenmh(edtten.getText().toString());
                mh.setSotiet(Integer.parseInt(edtsotiet.getText().toString()));
                if (dao.update(mh)) {
                    list.clear();
                    list.addAll(dao.selectAll());
                    notifyDataSetChanged();
                    Toast.makeText(context, "Update thành công", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Không thành công", Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }

        });

    }
    public boolean realnumber(String vr){

        try {
            // Chuyển đổi chuỗi thành số thực
            Integer.parseInt (vr);
            // Nếu không có ngoại lệ, trả về true
            return true;
        } catch (NumberFormatException e) {

//            if (Double.parseDouble (vr)>0){
//                Toast.makeText(getActivity(), "giá phải > 0", Toast.LENGTH_SHORT).show();
//            }
            // Nếu có ngoại lệ, trả về false
            return false;
        }
    }
    }

