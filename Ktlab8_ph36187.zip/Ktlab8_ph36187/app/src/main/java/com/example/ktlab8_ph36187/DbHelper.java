package com.example.ktlab8_ph36187;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {

    public DbHelper(@Nullable Context context) {
        super(context, "QLMH", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String tb_mh = "CREATE TABLE monhoc(mamh text primary key, tenmh text, sotiet int)";
        db.execSQL(tb_mh);
        String insert = "INSERT INTO monhoc VALUES('MH1','Java',25)";
        db.execSQL(insert);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion!=newVersion){
            db.execSQL("DROP TABLE IF EXISTS monhoc");
            onCreate(db);
        }
    }
}
