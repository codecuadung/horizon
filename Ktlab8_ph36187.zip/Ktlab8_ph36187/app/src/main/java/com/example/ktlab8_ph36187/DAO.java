package com.example.ktlab8_ph36187;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

public class DAO {
    private final DbHelper dbHelper;

    public DAO(Context context) {
        dbHelper = new DbHelper(context);
    }
    public ArrayList<monhocmodel>selectAll(){
        ArrayList<monhocmodel>list = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT*FROM monhoc",null);
            if(cursor.getCount()>0){
                cursor.moveToFirst();
                do {
                    list.add(new monhocmodel(cursor.getString(0),cursor.getString(1),cursor.getInt(2)));
                }while (cursor.moveToNext());
            }
        }catch (Exception e){
            Log.i(TAG,"loi",e);
        }
        return list;
    }
    public boolean insert(monhocmodel mh) {

        SQLiteDatabase db = dbHelper.getWritableDatabase();//ghi dl
        ContentValues values = new ContentValues();//dua dl vao database
        values.put("mamh",mh.getMamh());
        values.put("tenmh",mh.getTenmh());
        values.put("sotiet",mh.getSotiet());

        long row = db.insert("monhoc", null, values);

        return (row > 0);

    }
    public boolean update(monhocmodel mh) {

        SQLiteDatabase db = dbHelper.getWritableDatabase();//ghi dl
        ContentValues values = new ContentValues();//dua dl vao database
        values.put("mamh",mh.getMamh());
        values.put("tenmh",mh.getTenmh());
        values.put("sotiet",mh.getSotiet());
        long row = db.update("monhoc",values,"mamh=?",new String[]{mh.getMamh()});

        return (row > 0);

    }
    public  boolean delete(String mamh){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long row = db.delete("monhoc","mamh=?",new String[]{mamh});
        return (row>0);
    }
}
