package com.example.lab7_ph36187;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;

import com.example.lab7_ph36187.R;

public class bai2 extends AppCompatActivity {
ImageView imageView;
Button btnStart,btnStop,btnFast,btnMedium,btnSlow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);
        imageView = findViewById(R.id.imgbai2);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnOff);
        btnFast = findViewById(R.id.btnFast);
        btnMedium = findViewById(R.id.btnMedium);
        btnSlow= findViewById(R.id.btnSlow);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //định nghĩa hành động quay
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        imageView.animate()
                                .rotationBy(360)
                                .withEndAction(this)
                                .setDuration(500)
                                .setInterpolator(new LinearInterpolator())
                                .start();

                    }
                };
                //thực hiện hành động
                imageView.animate()
                        .rotationBy(360)
                        .withEndAction(runnable)
                        .setDuration(500)
                        .setInterpolator(new LinearInterpolator())
                        .start();
            }
        });
        btnSlow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //định nghĩa hành động quay
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        imageView.animate()
                                .rotationBy(360)
                                .withEndAction(this)
                                .setDuration(500)
                                .setInterpolator(new LinearInterpolator())
                                .start();

                    }
                };
                //thực hiện hành động
                imageView.animate()
                        .rotationBy(360)
                        .withEndAction(runnable)
                        .setDuration(8000)
                        .setInterpolator(new LinearInterpolator())
                        .start();
            }
        });
        btnMedium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //định nghĩa hành động quay
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        imageView.animate()
                                .rotationBy(360)
                                .withEndAction(this)
                                .setDuration(500)
                                .setInterpolator(new LinearInterpolator())
                                .start();

                    }
                };
                //thực hiện hành động
                imageView.animate()
                        .rotationBy(360)
                        .withEndAction(runnable)
                        .setDuration(500)
                        .setInterpolator(new LinearInterpolator())
                        .start();
            }
        });
        btnFast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //định nghĩa hành động quay
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        imageView.animate()
                                .rotationBy(360)
                                .withEndAction(this)
                                .setDuration(300)
                                .setInterpolator(new LinearInterpolator())
                                .start();

                    }
                };
                //thực hiện hành động
                imageView.animate()
                        .rotationBy(360)
                        .withEndAction(runnable)
                        .setDuration(300)
                        .setInterpolator(new LinearInterpolator())
                        .start();
            }
        });
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.animate().cancel();
            }
        });
    }
}