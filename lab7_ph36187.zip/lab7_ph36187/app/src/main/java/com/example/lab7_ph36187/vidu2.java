package com.example.lab7_ph36187;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;

public class vidu2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vidu2);
        ImageView imgso = findViewById(R.id.imgso);
        imgso.setBackgroundResource(R.drawable.anim_frame);
        AnimationDrawable frame = (AnimationDrawable) imgso.getBackground();
        frame.start();
    }
}