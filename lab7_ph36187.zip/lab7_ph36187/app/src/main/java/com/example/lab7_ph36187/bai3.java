package com.example.lab7_ph36187;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class bai3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai3);
    }
}