package com.example.lab7_ph36187;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class bai1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai1);
        ImageView imghinh = findViewById(R.id.imghinh);
        TextView txtten = findViewById(R.id.txtbai1);

        Animation anm1 = AnimationUtils.loadAnimation(this, R.anim.hieuung1b);
        imghinh.startAnimation(anm1);
        Animation anm2 = AnimationUtils.loadAnimation(this,R.anim.hieuungbai1a);
        txtten.startAnimation(anm2);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(bai1.this,login.class);
                startActivity(intent);
            }
        }, 3000);
    }
}