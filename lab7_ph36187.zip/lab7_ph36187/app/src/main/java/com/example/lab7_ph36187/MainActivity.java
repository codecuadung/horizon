package com.example.lab7_ph36187;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnbaitap1;
    Button btnBackbaitap2a;
    Button btnBackbaitap3a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnbaitap1 = findViewById(R.id.btnbaitap1);
        btnBackbaitap2a = findViewById(R.id.btnbaitap2);
        btnBackbaitap3a = findViewById(R.id.btnbaitap3);
        btnBackbaitap2a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bai2 = new Intent(MainActivity.this,bai2.class);
                startActivity(bai2);
            }
        });
        btnBackbaitap3a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bai3 = new Intent(MainActivity.this,bai3.class);
                startActivity(bai3);
            }
        });
        btnbaitap1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bai1 = new Intent(MainActivity.this,bai1.class);
                startActivity(bai1);
            }
        });

    }
}