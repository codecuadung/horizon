package com.example.btlab5_2.Model;

public class thucdonmodel {
    private int masp;
    private String tensp;
    private int giaban;

    public int getMasp() {
        return masp;
    }

    public void setMasp(int masp) {
        this.masp = masp;
    }

    public String getTensp() {
        return tensp;
    }

    public void setTensp(String tensp) {
        this.tensp = tensp;
    }

    public int getGiaban() {
        return giaban;
    }

    public void setGiaban(int giaban) {
        this.giaban = giaban;
    }

    public thucdonmodel(int masp, String tensp, int giaban) {
        this.masp = masp;
        this.tensp = tensp;
        this.giaban = giaban;
    }

    public thucdonmodel() {
    }
}
