package com.example.btlab5_2;
import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;


import com.example.btlab5_2.Adapter.thucdonadapter;
import com.example.btlab5_2.DAO.thucdondao;
import com.example.btlab5_2.Model.thucdonmodel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class frmtrangchu extends Fragment {
    private RecyclerView recyclerproduct;
    private FloatingActionButton floadadd;
    private thucdondao thucdondao;
    thucdonadapter adapter;
    private ArrayList<thucdonmodel>list = new ArrayList<>();
    public frmtrangchu() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_frmtrangchu,container,false);
        //ánh xạ
        recyclerproduct = view.findViewById(R.id.recyclerproduct);
        floadadd = view.findViewById(R.id.floadadd);
        thucdondao = new thucdondao(getContext());
        adapter = new thucdonadapter(getContext(),list);
         list = thucdondao.getds();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerproduct.setLayoutManager(linearLayoutManager);
        thucdonadapter adapter = new thucdonadapter(getContext(),list);
        recyclerproduct.setAdapter(adapter);
        floadadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendialogthem();
            }
        });



        return view;
    }
    public void opendialogthem(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view  = getLayoutInflater().inflate(R.layout.item_add,null);
        builder.setView(view);
        Dialog dialog = builder.create();
        dialog.show();

        EditText txtmasp = view.findViewById(R.id.txtmaspadd);
        EditText txttensp = view.findViewById(R.id.txttenadd);
        EditText txtgiasp = view.findViewById(R.id.txtgiaadd);
        Button btnthem = view.findViewById(R.id.btnthem);

        btnthem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String maspString = txtmasp.getText().toString();
                String tensp = txttensp.getText().toString();
                String giaspString = txtgiasp.getText().toString();

                int masp = Integer.parseInt(maspString); // Ép kiểu từ chuỗi sang số nguyên
                int giasp = Integer.parseInt(giaspString); // Ép kiểu từ chuỗi sang số nguyên

// Gọi constructor và khởi tạo đối tượng thucdonmodel
                thucdonmodel td = new thucdonmodel(masp, tensp, giasp);

                if(thucdondao.insert(td)){
                    list.clear();
                    list.addAll(thucdondao.getds());
                    adapter.notifyDataSetChanged();
                    dialog.dismiss();
                    Toast.makeText(requireContext(),"Thêm thành công",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(requireContext(),"Thêm thất bại",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}