package com.example.btlab5_2.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {

    public DbHelper(@Nullable Context context) {
        super(context,"thucdon",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String qsanpham = "CREATE TABLE THUCDON(masp INTEGER PRIMARY KEY AUTOINCREMENT,tensp TEXT, giaban INTEGER)";
        db.execSQL(qsanpham);
        String dSANPHAM = "INSERT INTO THUCDON VALUES('1','bánh','5000'),('2','kẹo','10000'),('3','LẨU','10000')";
        db.execSQL(dSANPHAM);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion!= newVersion){
            db.execSQL("DROP TABLE IF EXISTS SANPHAM");
            onCreate(db);
        }
    }
}
