package com.example.btlab5_2.Adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.btlab5_2.DAO.thucdondao;
import com.example.btlab5_2.Model.thucdonmodel;
import com.example.btlab5_2.R;

import java.util.ArrayList;

public class thucdonadapter extends RecyclerView.Adapter<thucdonadapter.ViewHolder> {
    private Context context;
    ArrayList<thucdonmodel>list;
    private thucdondao thucdondao;

    public thucdonadapter(Context context, ArrayList<thucdonmodel> list) {
        this.context = context;
        this.list = list;
        thucdondao = new thucdondao(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = ((Activity)context).getLayoutInflater();
        View view = inflater.inflate(R.layout.item_thucdon,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txtname.setText(list.get(position).getTensp());
        holder.txtprice.setText(String.valueOf(list.get(position).getGiaban()));
        holder.txtmasp.setText(String.valueOf(list.get(position).getMasp()));
        thucdonmodel td = list.get(position);
        holder.txtdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(thucdondao.delete(td.getMasp())){
                    list.clear();
                    list.addAll(thucdondao.getds());
                    Toast.makeText(context,"delete thành công",Toast.LENGTH_SHORT).show();
                    notifyDataSetChanged();
                }else {
                    Toast.makeText(context,"delete thất bại",Toast.LENGTH_SHORT).show();
                }
            }
        });

        holder.txtedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendialogsua(td);
            }

            private void opendialogsua(thucdonmodel td) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                LayoutInflater inflater = ((Activity)context).getLayoutInflater();
                View view = inflater.inflate(R.layout.item_update,null);
                builder.setView(view);
                Dialog dialog = builder.create();
                dialog.show();
                //ánh xạ
                EditText txtspud = view.findViewById(R.id.txttenud);
                EditText txtgiaud = view.findViewById(R.id.txtgiaud);
                EditText txtmaspud = view.findViewById(R.id.txtmaspud);
                Button btnsua = view.findViewById(R.id.btnsua);
                txtspud.setText(td.getTensp());
                txtspud.setText(td.getTensp());
                txtgiaud.setText(String.valueOf(td.getGiaban())); // Chuyển đổi thành chuỗi
                txtmaspud.setText(String.valueOf(td.getMasp())); // Chuyển đổi thành chuỗi


                btnsua.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        td.setTensp(txtspud.getText().toString()); // Chưa sửa lỗi ở dòng này
                        td.setMasp(Integer.valueOf(txtmaspud.getText().toString()));
                        td.setGiaban(Integer.valueOf(txtgiaud.getText().toString())); // Chuyển đổi sang kiểu số thực nếu giá tiền là số thực


                        if(thucdondao.update(td)){
                            list.clear();
                            list.addAll(thucdondao.getds());
                            notifyDataSetChanged();
                            dialog.dismiss();
                            Toast.makeText(context,"update thành công",Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(context,"update thất bại",Toast.LENGTH_SHORT).show();

                        }
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtname,txtprice,txtedit,txtdelete,txtmasp;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtmasp = itemView.findViewById(R.id.txtmasp);
            txtname = itemView.findViewById(R.id.txtName);
            txtprice = itemView.findViewById(R.id.txtprice);
            txtedit = itemView.findViewById(R.id.txtEdit);
            txtdelete = itemView.findViewById(R.id.txtDelete);

        }
    }
}
