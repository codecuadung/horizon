package com.example.btlab5_2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Bundle;
import android.service.dreams.DreamService;
import android.view.Gravity;
import android.view.MenuItem;

import com.example.btlab5_2.Adapter.thucdonadapter;
import com.example.btlab5_2.DAO.thucdondao;
import com.example.btlab5_2.Model.thucdonmodel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class Navigation extends AppCompatActivity {
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    NavigationView nav;
    RecyclerView recyclerView;
    FloatingActionButton floadadd;
    private ArrayList<thucdonmodel>list = new ArrayList<>();
    thucdonadapter adapter;
    thucdondao thucdondao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);

        drawerLayout= findViewById(R.id.drawerLayout);
        toolbar= findViewById(R.id.toobar);
        nav= findViewById(R.id.nav);


        //gán toobar lên
        setSupportActionBar(toolbar);

        //setup toggle
        ActionBarDrawerToggle toggle= new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        toggle.syncState();
        //set frm
        getSupportFragmentManager().beginTransaction().replace(R.id.frmnav,new frmtrangchu()).commit();

        //Xử lý sự kiện khi click chọn item
        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId()==R.id.qltd){
                    frmtrangchu frgtrangchu= new frmtrangchu();// Tạo đôi tượng
                    replaceFtg(frgtrangchu);
                    getSupportActionBar().setTitle(item.getTitle());
                    if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                        drawerLayout.closeDrawer(GravityCompat.START); // Đóng drawer nếu nó đang mở
                    } else {
                        drawerLayout.openDrawer(GravityCompat.START); // Mở drawer nếu nó đã đóng
                    }
                    return true;
                }
                else{
                    if(item.getItemId()==R.id.lienhe){
                        frmcaidat frgcaidat= new frmcaidat(); // Taọ đối tượng
                        replaceFtg(frgcaidat);
                        getSupportActionBar().setTitle(item.getTitle());
                        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                            drawerLayout.closeDrawer(GravityCompat.START); // Đóng drawer nếu nó đang mở

                        } else {
                            drawerLayout.openDrawer(GravityCompat.START); // Mở drawer nếu nó đã đóng
                        }
                        return true;
                    }
                }
                return false;
            }
        });
    }
    //pt
    public void replaceFtg(Fragment frg){
        FragmentManager fm= getSupportFragmentManager();
        fm.beginTransaction().replace(R.id.frmnav, frg).commit();
    }
}