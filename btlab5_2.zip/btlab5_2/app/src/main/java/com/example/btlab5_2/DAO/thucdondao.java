package com.example.btlab5_2.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import com.example.btlab5_2.Database.DbHelper;
import com.example.btlab5_2.Model.thucdonmodel;

import java.util.ArrayList;

public class thucdondao {
    private DbHelper dbHelper;

    public thucdondao(Context context) {
        dbHelper = new DbHelper(context);
    }
    //lấy ds thực đơn
    public ArrayList<thucdonmodel>getds(){
        ArrayList<thucdonmodel> list = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = dbHelper.getReadableDatabase();

        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM thucdon",null);
        if(cursor.getCount()>0){
            cursor.moveToFirst();
            do{
                list.add(new thucdonmodel(cursor.getInt(0),cursor.getString(1),cursor.getInt(2)));

            }while (cursor.moveToNext());
        }
        return list;
    }
    public boolean insert(thucdonmodel td) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();//ghi dl vào db
        ContentValues values = new ContentValues();//đưa dl vào database
        values.put("masp",td.getMasp());
        values.put("tensp",td.getTensp());
        values.put("giaban",td.getGiaban());
        //nếu add dl thành công thì trả về giá trị tương ứng với số dòng được chèn vào
        long row = db.insert("thucdon",null,values);
        return (row>0);

    }
    //update dl
    public boolean update(thucdonmodel td){
        SQLiteDatabase db = dbHelper.getWritableDatabase();//ghi dl vào db
        ContentValues values = new ContentValues();//đưa dl vào database
        values.put("masp",td.getMasp());
        values.put("tensp",td.getTensp());
        values.put("giaban",td.getGiaban());
        //nếu add dl thành công thì trả về giá trị tương ứng với số dòng được chèn vào
        long row = db.update("thucdon",values,"masp = ?",new String[]{String.valueOf(td.getMasp())});
        //điều kiện update nằm ở cột id
        return (row>0);
    }
    //xóa dl
    //tham số truyền vào là congviec hoặc giá trị cột
    public boolean delete(int id){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long row = db.delete("thucdon","masp = ?",new String[]{String.valueOf(id)});
        return (row>0);
    }
}
