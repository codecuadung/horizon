package com.example.asignment_adr2.adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.asignment_adr2.DAO.nguoiDungDAO;
import com.example.asignment_adr2.Model.sanphammodel;
import com.example.asignment_adr2.R;


import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;

public class sanphamadapter extends RecyclerView.Adapter<sanphamadapter.Viewholder> {
    private final Context context;
    private final ArrayList<sanphammodel>list;
    nguoiDungDAO dao;

    public sanphamadapter(Context context, ArrayList<sanphammodel> list) {
        this.context = context;
        this.list = list;
        dao = new nguoiDungDAO(context);
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = ((Activity)context).getLayoutInflater();
        View view = inflater.inflate(R.layout.item_sanpham,parent,false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        holder.txtten.setText(list.get(position).getTensp());
        holder.txtsoluong.setText(String.valueOf(list.get(position).getSoluong()));
        holder.txtgia.setText(String.valueOf(list.get(position).getGiaban()));
        sanphammodel sp = list.get(position);
        NumberFormat format = new DecimalFormat("#,###");;
        double myNumber = list.get(position).getGiaban();
        String formattedNumber = format.format(myNumber);

        holder.txtgia.setText(formattedNumber + "VND");
        holder.txtdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);//tạo đối tượng
                builder.setIcon(R.drawable.baseline_warning_amber_24);//set icon
                builder.setTitle("Cảnh báo");
                builder.setMessage("Bạn có chắc chắn muốn xóa không?");
                //button yes
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (dao.delete(sp.getMasp())) { // Gọi phương thức delete với tên sản phẩm trực tiếp
                            list.clear();
                            list.addAll(dao.getds());
                            Toast.makeText(context, "delete thành công", Toast.LENGTH_SHORT).show();
                            notifyDataSetChanged();
                        } else {
                            Toast.makeText(context, "delete thất bại", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                //tạo button no
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context,"Không xóa",Toast.LENGTH_SHORT).show();
                    }
                });
                //
                AlertDialog dialog = builder.create();//tạo hộp thoại
                dialog.show();//hiển thị hộp thoại
            }
        });

        holder.txtedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendialogsua(sp);
            }
            private void opendialogsua(sanphammodel sp) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                LayoutInflater inflater = ((Activity)context).getLayoutInflater();
                View view = inflater.inflate(R.layout.item_update,null);
                builder.setView(view);
                Dialog dialog = builder.create();
                dialog.show();
                //ánh xạ
                EditText txtsoluongud = view.findViewById(R.id.txtsoluongud);
                EditText txtgiaud = view.findViewById(R.id.txtgiaud);
                EditText txttenspud = view.findViewById(R.id.txttenud);
                Button btnupdate = view.findViewById(R.id.btnupdate);
                txttenspud.setText(sp.getTensp());
                txtgiaud.setText(String.valueOf(sp.getGiaban())); // Chuyển đổi thành chuỗi
                txtsoluongud.setText(String.valueOf(sp.getSoluong())); // Chuyển đổi thành chuỗi


                btnupdate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String sl =txtsoluongud.getText().toString();
                        String giaString = txtgiaud.getText().toString();
                        String ten = txttenspud.getText().toString();
                        if (giaString.isEmpty()||sl.isEmpty()||ten.isEmpty()) {
                            Toast.makeText(context, "Giá bán không được để trống", Toast.LENGTH_SHORT).show();
                        } else {

                            sp.setTensp(ten);
                            sp.setSoluong(Integer.valueOf(sl));
                            sp.setGiaban(Double.valueOf(giaString));

                            if (dao.update(sp)) {
                                list.clear();
                                list.addAll(dao.getds());
                                notifyDataSetChanged();
                                dialog.dismiss();
                                Toast.makeText(context, "Update thành công", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(context, "Update thất bại", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });


            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView txtten,txtgia,txtsoluong,txtedit,txtdelete;
        public Viewholder(@NonNull View itemView) {
            super(itemView);
            txtten = itemView.findViewById(R.id.txtName);
            txtgia = itemView.findViewById(R.id.txtgia);
            txtsoluong = itemView.findViewById(R.id.txtsl);
            txtedit = itemView.findViewById(R.id.txtEdit);
            txtdelete = itemView.findViewById(R.id.txtDelete);
        }
    }
}
