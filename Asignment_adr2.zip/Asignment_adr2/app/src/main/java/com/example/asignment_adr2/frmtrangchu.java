package com.example.asignment_adr2;

import android.app.Dialog;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.example.asignment_adr2.Model.sanphammodel;
import com.example.asignment_adr2.adapter.sanphamadapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.example.asignment_adr2.DAO.nguoiDungDAO;
import java.util.ArrayList;


public class frmtrangchu extends Fragment {

    private RecyclerView rcvsanpham;
    private FloatingActionButton floadadd;
    private nguoiDungDAO nguoiDungDAO;
    sanphamadapter adapter;
    private ArrayList<sanphammodel> list = new ArrayList<>();

    public frmtrangchu() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_frmtrangchu, container, false);
        // Inflate the layout for this fragment
        rcvsanpham = view.findViewById(R.id.recyclerproduct);
        floadadd = view.findViewById(R.id.floadadd);
        nguoiDungDAO = new nguoiDungDAO(getContext());
        list = nguoiDungDAO.getds();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        rcvsanpham.setLayoutManager(linearLayoutManager);
        adapter = new sanphamadapter(getContext(), list);
        rcvsanpham.setAdapter(adapter);
        floadadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendialogthem();
            }
        });
        return view;
    }

    public void opendialogthem() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = getLayoutInflater().inflate(R.layout.item_add, null);
        builder.setView(view);
        Dialog dialog = builder.create();
        dialog.show();

        EditText txttensp = view.findViewById(R.id.txttenadd);
        EditText txtgiasp = view.findViewById(R.id.txtgiaadd);
        EditText txtsoluong = view.findViewById(R.id.txtsoluongadd);
        Button btnthem = view.findViewById(R.id.btnthem);

        btnthem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String soluongString = txtsoluong.getText().toString();
                String tensp = txttensp.getText().toString();
                String giaspString = txtgiasp.getText().toString();

                if (soluongString.isEmpty() || tensp.isEmpty() || giaspString.isEmpty()) {
                    Toast.makeText(requireContext(), "Không được bỏ trống thông tin", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        int soluong = Integer.parseInt(soluongString); // Ép kiểu từ chuỗi sang số nguyên
                        double giasp = Double.parseDouble(giaspString); // Ép kiểu từ chuỗi sang số thực

                        sanphammodel sp = new sanphammodel(tensp, giasp, soluong);
                        if(nguoiDungDAO.insert(sp)){
                            list.clear();
                            list.addAll(nguoiDungDAO.getds());
                            adapter.notifyDataSetChanged();
                            dialog.dismiss();
                            Toast.makeText(requireContext(),"Thêm thành công",Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(requireContext(),"Thêm thất bại",Toast.LENGTH_SHORT).show();
                        }

                        // Tiếp tục xử lý khi soluong và giasp là số
                    } catch (NumberFormatException e) {
                        Toast.makeText(requireContext(), "Số lượng và giá sản phẩm phải là số", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}