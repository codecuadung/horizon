package com.example.asignment_adr2;


import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.service.dreams.DreamService;
import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;

public class NaViGaTiOn extends AppCompatActivity {
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    NavigationView nav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_na_vi_ga_ti_on);

        drawerLayout= findViewById(R.id.drawerLayout);
        toolbar= findViewById(R.id.toobar);
        nav= findViewById(R.id.nav);

        //gán toobar lên
        setSupportActionBar(toolbar);
        toolbar.setBackground(new ColorDrawable(Color.RED));
        //setup toggle
        ActionBarDrawerToggle toggle= new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        toggle.syncState();
        getSupportFragmentManager().beginTransaction().replace(R.id.frmnav,new frmtrangchu()).commit();
        //Xử lý sự kiện khi click chọn item
        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId()==R.id.trangchu){
                    frmtrangchu frgtrangchu= new frmtrangchu();// Tạo đôi tượng
                    replaceFtg(frgtrangchu);
                    getSupportActionBar().setTitle(item.getTitle());
                    if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                        drawerLayout.closeDrawer(GravityCompat.START); // Đóng drawer nếu nó đang mở
                    } else {
                        drawerLayout.openDrawer(GravityCompat.START); // Mở drawer nếu nó đã đóng
                    }
                    return true;
                }
                else{
                    if(item.getItemId()==R.id.dautrang){
                        frmgioithieu frgcaidat= new frmgioithieu(); // Taọ đối tượng
                        replaceFtg(frgcaidat);
                        getSupportActionBar().setTitle(item.getTitle());
                        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                            drawerLayout.closeDrawer(GravityCompat.START); // Đóng drawer nếu nó đang mở

                        } else {
                            drawerLayout.openDrawer(GravityCompat.START); // Mở drawer nếu nó đã đóng
                        }
                        return true;
                    }
                }
                return false;
            }
        });
    }
    //pt
    public void replaceFtg(Fragment frg){
        FragmentManager fm= getSupportFragmentManager();
        fm.beginTransaction().replace(R.id.frmnav, frg).commit();
    }
}