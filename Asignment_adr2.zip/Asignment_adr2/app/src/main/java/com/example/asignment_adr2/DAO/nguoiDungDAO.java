package com.example.asignment_adr2.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.asignment_adr2.Database.DbHelper;
import com.example.asignment_adr2.Model.sanphammodel;


import java.util.ArrayList;

public class nguoiDungDAO {
    private DbHelper dbHelper;

    public nguoiDungDAO(Context context) {
        dbHelper = new DbHelper(context);
    }
    //login
    public boolean checklogin(String username, String password){
        SQLiteDatabase sqLiteDatabase = dbHelper.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM NGUOIDUNG WHERE tendangnhap = ? AND matkhau = ?",new String[]{username,password});
        if(cursor.getCount()>0){
            return true;
        }else {
            return false;
        }
    }
    //register
    public boolean Register(String username, String password/*,String hoten*/){
        SQLiteDatabase sqLiteDatabase = dbHelper.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("tendangnhap",username);
        contentValues.put("matkhau",password);
        /*contentValues.put("hoten",hoten);*/
        long check = sqLiteDatabase.insert("NGUOIDUNG",null,contentValues);
        if(check!= -1){
            return true;
        }else {
            return false;
        }
    }
    //forgot
    public String forgotpassword(String email){
        SQLiteDatabase sqLiteDatabase = dbHelper.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT matkhau FROM NGUOIDUNG WHERE tendangnhap = ?",new String[]{email});
        if(cursor.getCount()>0){
            cursor.moveToFirst();
            return cursor.getString(0);
        }else {
            return "Không có dữ liệu";
        }
    }
    public ArrayList<sanphammodel> getds() {
        ArrayList<sanphammodel> list = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = dbHelper.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM SANPHAM", null);

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(0);
                String tensp = cursor.getString(1);
                double giaban = cursor.getDouble(2);
                int soluong = cursor.getInt(3);

                list.add(new sanphammodel(id, tensp, giaban, soluong));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }
    public boolean insert(sanphammodel sp) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();//ghi dl vào db
        ContentValues values = new ContentValues();//đưa dl vào database
        values.put("tensp",sp.getTensp());
        values.put("giaban",sp.getGiaban());
        values.put("soluong",sp.getSoluong());
        //nếu add dl thành công thì trả về giá trị tương ứng với số dòng được chèn vào
        long row = db.insert("sanpham",null,values);
        return (row>0);

    }
    //update dl
    public boolean update(sanphammodel sp){
        SQLiteDatabase db = dbHelper.getWritableDatabase();//ghi dl vào db
        ContentValues values = new ContentValues();//đưa dl vào database
        values.put("tensp",sp.getTensp());
        values.put("giaban",sp.getGiaban());
        values.put("soluong",sp.getSoluong());
        //nếu add dl thành công thì trả về giá trị tương ứng với số dòng được chèn vào
        long row = db.update("sanpham",values,"masp = ?",new String[]{String.valueOf(sp.getMasp())});
        //điều kiện update nằm ở cột id
        return (row>0);
    }
    //xóa dl
    //tham số truyền vào là congviec hoặc giá trị cột
    public boolean delete(String tensp) {
        SQLiteDatabase sqLiteDatabase = dbHelper.getWritableDatabase();
        int result = sqLiteDatabase.delete("SANPHAM", "masp=?", new String[]{tensp});
        return result > 0;
    }

}

