package com.example.asignment_adr2;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.example.asignment_adr2.DAO.nguoiDungDAO;

public class DangNhap extends AppCompatActivity {
    private nguoiDungDAO nguoiDungDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_nhap);
        //ánh xạ
        EditText edtuser = findViewById(R.id.edtUser);
        EditText edtpass = findViewById(R.id.edtPass);
        Button btnlogin = findViewById(R.id.btnLogin);
        TextView txtforgot = findViewById(R.id.txtForgot);
        TextView txtsignup = findViewById(R.id.txtSignup);
        nguoiDungDAO = new nguoiDungDAO(this);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = edtuser.getText().toString();
                String pass = edtpass.getText().toString();
                boolean check = nguoiDungDAO.checklogin(user,pass);
                if(check){
                    Toast.makeText(DangNhap.this,"Đăng nhập thành công",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(DangNhap.this,NaViGaTiOn.class));
                }else {
                    Toast.makeText(DangNhap.this,"Đăng nhập thất bại",Toast.LENGTH_SHORT).show();
                }
            }
        });
        txtsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DangNhap.this,DangKy.class));
            }
        });
        txtforgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdialogforgot();
            }
        });
    }
    public void showdialogforgot(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.item_dialogforgot,null);
        builder.setView(view);

        AlertDialog alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
        //ánh xạ

        EditText edtemail = view.findViewById(R.id.edtemail);
        Button btnsend = view.findViewById(R.id.btnsend);
        Button btncancel = view.findViewById(R.id.btncancel);

        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
        btnsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edtemail.getText().toString();
                if(email.isEmpty()){
                    Toast.makeText(DangNhap.this,"Vui lòng nhập user",Toast.LENGTH_SHORT).show();
                }else {
                    String matkhau = nguoiDungDAO.forgotpassword(email);
                    Toast.makeText(DangNhap.this,matkhau,Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}