package com.example.asignment_adr2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.asignment_adr2.DAO.nguoiDungDAO;

public class DangKy extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_ky);
        EditText edtuser = findViewById(R.id.edtuser);
        EditText edtpass = findViewById(R.id.edtpassword);
        EditText edtrepass = findViewById(R.id.edtrepassword);
        /*EditText edtfullname = findViewById(R.id.edthoten);*/
        Button btnregister = findViewById(R.id.btnregister);
        Button btnback = findViewById(R.id.btnback);
        nguoiDungDAO nguoiDungDAO = new nguoiDungDAO(this);

        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = edtuser.getText().toString();
                String pass = edtpass.getText().toString();
                String repass = edtrepass.getText().toString();
                /*String fullname = edtfullname.getText().toString();*/

                if(user.isEmpty()||pass.isEmpty()||repass.isEmpty()){
                    Toast.makeText(DangKy.this,"Đăng ký thất bại",Toast.LENGTH_SHORT).show();
                }else if(!pass.equals(repass)){
                    Toast.makeText(DangKy.this,"mật khẩu phải trùng nhau",Toast.LENGTH_SHORT).show();
                }else {
                    boolean check = nguoiDungDAO.Register(user,pass/*,fullname*/);
                    if(check){
                        Toast.makeText(DangKy.this,"Đăng ký thành công",Toast.LENGTH_SHORT).show();
                        finish();
                    }else {
                        Toast.makeText(DangKy.this,"Đăng ký thất bại",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}