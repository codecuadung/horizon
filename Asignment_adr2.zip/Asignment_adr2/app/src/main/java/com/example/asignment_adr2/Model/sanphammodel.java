package com.example.asignment_adr2.Model;

public class sanphammodel {
    String masp;
    String tensp;
    double giaban;
    int soluong;

    public String getMasp() {
        return masp;
    }

    public void setId(String id) {
        this.masp = id;
    }

    public String getTensp() {
        return tensp;
    }

    public void setTensp(String tensp) {
        this.tensp = tensp;
    }

    public double getGiaban() {
        return giaban;
    }

    public void setGiaban(double giaban) {
        this.giaban = giaban;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public sanphammodel(String tensp, double giaban, int soluong) {
        this.tensp = tensp;
        this.giaban = giaban;
        this.soluong = soluong;
    }

    public sanphammodel(String masp, String tensp, double giaban, int soluong) {
        this.masp = masp;
        this.tensp = tensp;
        this.giaban = giaban;
        this.soluong = soluong;
    }

    public sanphammodel() {
    }
}

